import sys
from PySide6.QtWidgets import QApplication,QMainWindow,QPushButton,QLabel,QTableWidget,QTableWidgetItem,QFrame
import task7backend
from PySide6.QtGui import QColor
import time

class bfsgui(QMainWindow):
    def __init__(self):
        self.j=0
        super(bfsgui,self).__init__()
        self.index=0
        self.array=task7backend.bfs([0,0],[9,9])
        self.frame=QFrame()
        self.frame.setGeometry(0,0,1000,1000)
        self.frame.setWindowTitle('bfs')
        self.frame.show()
        self.table=QTableWidget(10,10,self.frame)
        self.table.setGeometry(0,100,1000,1000)
        for i in range(10):
            for j in range(10):
                if task7backend.grid[i][j]==1:
                    self.table.setCellWidget(i,j,QLabel(str(1)))
                else:
                    self.table.setCellWidget(i,j,QLabel(str(0)))
                if task7backend.grid[i][j]==0:
                    colour=QTableWidgetItem()
                    colour.setBackground(QColor.fromRgb(int('222840',16)))
                    self.table.setItem(i,j,colour)
        self.table.show()
        self.b=QPushButton("next",self.frame)
        self.b.setGeometry(0,50,50,50)
        self.b.show()
        self.b.clicked.connect(self.changec)

    def changec(self):
            colour=QTableWidgetItem()
            colour.setBackground(QColor.fromRgb(int('F9E56d',16)))
            if self.index==0:
                colour.setBackground(QColor.fromRgb(int('FF0000',16)))
            if self.array[self.index]==[9,9]:
                colour.setBackground(QColor.fromRgb(int('00FF00',16)))
            self.table.setItem(int(self.array[self.index][0]),int(self.array[self.index][1]),colour)
            self.table.show()
            if self.index<self.array.__len__()-1:
                self.index+=1
                if self.index==self.array.__len__()-1 and self.j==0:
                    print(self.array)
                    self.j+=1

    
            
        
class astargui(QMainWindow):
    def __init__(self):
        self.n=0
        self.n2=0
        super(astargui,self).__init__()
        self.frame=QFrame()
        self.frame.setWindowTitle('astar')
        self.frame.setGeometry(300,300,1100,1100)
        self.frame.show()
        self.answer=task7backend.astar((0,0),(9,9))
        self.keys=[]
        self.keys2=[]
        for i in self.answer[2]:
            self.keys.append(i)
        for key in self.answer[3]:
            self.keys2.append(key)
        self.b=QPushButton(self.frame)
        self.b.setText("next")
        self.b.setGeometry(0,50,50,50)
        self.b.show()
        self.table=QTableWidget(10,10,self.frame)
        self.table.setGeometry(0,100,1000,1000)
        for i in range(10):
            for j in range(10):
                if task7backend.grid[i][j]==1:
                    self.table.setCellWidget(i,j,QLabel(str(1)))

                else:
                    self.table.setCellWidget(i,j,QLabel(str(0)))
                if task7backend.grid[i][j]==0:
                    c=QTableWidgetItem()
                    c.setBackground(QColor.fromRgb(int('222840',16)))
                    self.table.setItem(i,j,c)

        self.table.show()
        self.b.clicked.connect(self.changec)
  

    def changec(self):
        colour=QTableWidgetItem()
        colour.setBackground(QColor.fromRgb(int('F9E56d',16)))
        if self.n==0:
            colour.setBackground(QColor.fromRgb(int('FF0000',16)))
        if self.n==len(self.keys2)-1:
            colour.setBackground(QColor.fromRgb(int('00FF00',16)))
        self.table.setItem(int(self.keys2[self.n][0]),int(self.keys2[self.n][1]),colour)
        self.table.show()
        if self.n<len(self.keys2)-1:
            self.n+=1
        else :  
            if (self.n==len(self.keys2)-1 and self.n2==0):
                print(self.answer)            
            colour=QTableWidgetItem()
            colour.setBackground(QColor.fromRgb(int('00FF00',16)))
            self.table.setItem(int(self.keys[self.n2][0]),int(self.keys[self.n2][1]),colour)
            self.table.show()
            if self.n2<len(self.keys)-1:
                self.n2+=1
        

if __name__ == "__main__":
    app = QApplication(sys.argv)
    b=bfsgui()
    a=astargui()
    sys.exit(app.exec())