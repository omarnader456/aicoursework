from rdflib import Graph, URIRef, Literal, Namespace, RDF

g = Graph()

ns=Namespace("http://example.org/")

boat1=URIRef("http://example.org/boat/b1")
boat2=URIRef("http://example.org/boat/b2")
boat3=URIRef("http://example.org/boat/b3")
boat4=URIRef("http://example.org/boat/b4")

leave1=URIRef("http://example.org/leave/l1")
leave2=URIRef("http://example.org/leave/l2")
leave3=URIRef("http://example.org/leave/l3")
leave4=URIRef("http://example.org/leave/l4")


arrive1=URIRef("http://example.org/arrive/a1")
arrive2=URIRef("http://example.org/arrival/a2")
arrive3=URIRef("http://example.org/arrival/a3")
arrive4=URIRef("http://example.org/arrival/a4")


cost1=URIRef("http://example.org/cost/c1")
cost2=URIRef("http://example.org/cost/c2")
cost3=URIRef("http://example.org/cost/c3")

g.add((boat1,RDF.type,ns.Boat))
g.add((boat1, ns.title, Literal("boat1")))
g.add((boat1, ns.start, leave1))
g.add((boat1, ns.end, arrive1))
g.add((boat1, ns.c, cost1))
g.add((boat1, ns.c, cost2))
g.add((boat1, ns.c, cost3))

g.add((boat2,RDF.type,ns.Boat))
g.add((boat2, ns.title, Literal("boat2")))
g.add((boat2, ns.start, leave2))
g.add((boat2, ns.end, arrive2))
g.add((boat2, ns.c, cost1))
g.add((boat2, ns.c, cost2))
g.add((boat2, ns.c, cost3))


g.add((boat3,RDF.type,ns.Boat))
g.add((boat3, ns.title, Literal("boat3")))
g.add((boat3, ns.start, leave3))
g.add((boat3, ns.end, arrive3))
g.add((boat3, ns.c, cost1))
g.add((boat3, ns.c, cost2))
g.add((boat3, ns.c, cost3))


g.add((boat4,RDF.type,ns.Boat))
g.add((boat4, ns.title, Literal("boat4")))
g.add((boat4, ns.start, leave4))
g.add((boat4, ns.end, arrive4))
g.add((boat4, ns.c, cost1))
g.add((boat4, ns.c, cost2))
g.add((boat4, ns.c, cost3))


g.add((leave1,RDF.type,ns.Leave))
g.add((leave1,ns.name, Literal("9 am")))

g.add((leave2,RDF.type,ns.Leave))
g.add((leave2,ns.name, Literal("10 am")))

g.add((leave3,RDF.type,ns.Leave))
g.add((leave3,ns.name, Literal("11 am")))

g.add((leave4,RDF.type,ns.Leave))
g.add((leave4,ns.name, Literal("12 pm")))


g.add((arrive1,RDF.type,ns.Arrive))
g.add((arrive1,ns.name, Literal(" 1 pm")))

g.add((arrive2,RDF.type,ns.Arrive))
g.add((arrive2,ns.name, Literal(" 2 pm")))

g.add((arrive3,RDF.type,ns.Arrive))
g.add((arrive3,ns.name, Literal(" 3 pm")))

g.add((arrive4,RDF.type,ns.Arrive))
g.add((arrive4,ns.name, Literal(" 4 pm ")))



g.add((cost1,RDF.type,ns.Cost))
g.add((cost1,ns.value,Literal("$100")))

g.add((cost2,RDF.type,ns.Cost))
g.add((cost2,ns.value,Literal("$50")))

g.add((cost3,RDF.type,ns.Cost))
g.add((cost3,ns.value,Literal("$25")))

print(g.serialize(format="turtle"))

q="""
 PREFIX ns: <http://example.org/>
    SELECT ?aBoat ?aLeave ?aArrive (GROUP_CONCAT(?aCost; SEPARATOR=", ") AS ?costs)
    WHERE {
        ?boat ns:title ?aBoat .
        ?boat ns:start ?leaving .
        ?leaving ns:name ?aLeave .
        ?boat ns:end ?arriving .
        ?arriving ns:name ?aArrive .
        ?boat ns:c ?amount .
        ?amount ns:value ?aCost .
    }
    GROUP BY ?aBoat
"""

for row in g.query(q):
    print(f"train: {row.aBoat}, departure: {row.aLeave}, arrival: {row.aArrive}, cost: {row.costs} ")