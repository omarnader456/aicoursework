from queue import PriorityQueue

grid=[[1,0,0,0,0,1,0,1,1,1],[1,1,0,1,0,1,0,1,0,1],[0,1,0,1,0,1,1,1,0,1],[1,1,1,1,0,0,0,0,0,1],[1,0,0,0,0,1,1,1,0,1],[1,1,1,1,1,1,0,1,0,1],
      [0,1,0,0,0,0,0,1,0,1],[1,1,1,1,1,1,1,1,0,1],[1,0,0,0,0,0,0,0,0,1],[1,1,1,1,1,1,1,1,1,1]]


def heuristic(point,end):
    return abs(end[0]-point[0])+abs(end[1]-point[1])

    

def bfs(start,goal):
    visited=[]
    queue=[]
    visited.append(start)
    queue.append(start)
    while queue:
        if queue[0]==goal:
            return visited 
        vertex=queue.pop(0)
        if vertex[0]>=0 and vertex[0]<10 and vertex[1]+1>=0 and vertex[1]+1<10 and grid[vertex[0]][vertex[1]+1]!=0:
            if [vertex[0],vertex[1]+1] not in visited:
                visited.append([vertex[0],vertex[1]+1])
                queue.append([vertex[0],vertex[1]+1])
        if vertex[0]>=0 and vertex[0]<10 and vertex[1]-1>=0 and vertex[1]-1<10 and grid[vertex[0]][vertex[1]-1]!=0:
            if [vertex[0],vertex[1]-1] not in visited:
                visited.append([vertex[0],vertex[1]-1])
                queue.append([vertex[0],vertex[1]-1])
        if vertex[0]+1>=0 and vertex[0]+1<10 and vertex[1]>=0 and vertex[1]<10 and grid[vertex[0]+1][vertex[1]]!=0:
            if [vertex[0]+1,vertex[1]] not in visited:
                visited.append([vertex[0]+1,vertex[1]])
                queue.append([vertex[0]+1,vertex[1]])
        if vertex[0]-1>=0 and vertex[0]-1<10 and vertex[1]>=0 and vertex[1]<10 and grid[vertex[0]-1][vertex[1]]!=0:
            if [vertex[0]-1,vertex[1]] not in visited:
                visited.append([vertex[0]-1,vertex[1]])
                queue.append([vertex[0]-1,vertex[1]])            
    return visited


def astar(start,end):
    pq=PriorityQueue()
    visited={}
    pq.put((heuristic(start,end),0,start,[start]))
    visited[start]=heuristic(start,end)
    while  not pq.empty():
        total,cost,vertex,path=pq.get()
        if vertex==end:
            return total,cost,path,visited
        currentcost=0
        if vertex[0]>=0 and vertex[0]<10 and vertex[1]+1>=0 and vertex[1]+1<10 and grid[vertex[0]][vertex[1]+1]!=0:
            currentcost=cost+1
            vertex2=(vertex[0],vertex[1]+1)
            total=heuristic(vertex2, end)+currentcost
            if (vertex[0],vertex[1]+1) not in visited.keys() or visited[vertex[0],vertex[1]+1]>=total:
                visited[vertex[0],vertex[1]+1]=total
                pq.put((total,currentcost,(vertex[0],vertex[1]+1),path+[[vertex[0],vertex[1]+1]]))
        if vertex[0]>=0 and vertex[0]<10 and vertex[1]-1>=0 and vertex[1]-1<10 and grid[vertex[0]][vertex[1]-1]!=0:
            currentcost=cost+1
            vertex2=(vertex[0],vertex[1]-1)
            total=heuristic(vertex2,end) +currentcost
            if (vertex[0],vertex[1]-1) not in visited.keys() or visited[vertex[0],vertex[1]-1]>=total:
                visited[vertex[0],vertex[1]-1]=total
                pq.put((total,currentcost,(vertex[0],vertex[1]-1),path+[[vertex[0],vertex[1]-1]])) 
        if vertex[0]+1>=0 and vertex[0]+1<10 and vertex[1]>=0 and vertex[1]<10 and grid[vertex[0]+1][vertex[1]]!=0:
            currentcost=cost+1
            vertex2=(vertex[0]+1,vertex[1])
            total=heuristic(vertex2,end)+currentcost
            if (vertex[0]+1,vertex[1]) not in visited.keys() or visited[vertex[0]+1,vertex[1]]>=total:
                visited[vertex[0]+1,vertex[1]]=total
                pq.put((total,currentcost,(vertex[0]+1,vertex[1]),path+[[vertex[0]+1,vertex[1]]]))
        if vertex[0]-1>=0 and vertex[0]-1<10 and vertex[1]>=0 and vertex[1]<10 and grid[vertex[0]-1][vertex[1]]!=0:
            currentcost=cost+1
            vertex2=(vertex[0]-1,vertex[1])
            total=heuristic(vertex2,end)+currentcost
            if (vertex[0]-1,vertex[1]) not in visited.keys() or visited[vertex[0]-1,vertex[1]]>=total:
                visited[vertex[0]-1,vertex[1]]=total
                pq.put((total,currentcost,(vertex[0]-1,vertex[1]),path+[[vertex[0]-1,vertex[1]]]))
    return visited


