from queue import PriorityQueue
import math
import sys
from PySide6.QtWidgets import QApplication,QMainWindow,QPushButton,QLabel,QTableWidget,QTableWidgetItem,QFrame,QLineEdit
from PySide6 import QtCore

problems=[[1,2,3,4,7,6,8,0,5],[1,0,3,4,6,7,8,2,5],[2,3,1,0,8,5,4,6,7],[8,5,0,3,2,1,7,6,4],[3,2,1,6,5,4,0,8,7]]

def heuristic(node):
    count=0
    goal=(1,2,3,4,5,6,7,8,0)
    for i in range(9):
        count+=abs(goal[i]-node[i])
    return count

def heuristic2(node):
    count=0
    goal=(1,2,3,4,5,6,7,8,0)
    for i in range(9):
        if node[i]!=goal[i]:
            count+=1
    return count

def astar(start,goal,x):
    pq=PriorityQueue()
    visited={}
    if x==1:
        h=heuristic(start)
    else:
        h=heuristic2(start)
    visited[start]=h
    pq.put((h,0,start,[start]))
    while not pq.empty():
        h,cost,vertex,path=pq.get()
        if vertex==goal:
            return h,cost,path
        currentcost =cost+1
        for i in range(9):
            if vertex[i]==0:
                    if i%3!=2 :
                        vertex2=list(vertex[:])
                        vertex2[i],vertex2[i+1]=vertex2[i+1],vertex2[i]
                        vertex2=tuple(vertex2)
                        if x==1:
                            h=heuristic(vertex2)
                        else:
                            h=heuristic2(vertex2)
                        total=h+currentcost
                        if vertex2 not in visited or visited[vertex2]>total:
                            visited[vertex2]=total
                            pq.put((total,currentcost,vertex2,path+[vertex2]))
                    if i%3!=0:
                        vertex2=list(vertex[:])
                        vertex2[i],vertex2[i-1]=vertex2[i-1],vertex2[i]
                        vertex2=tuple(vertex2)
                        if x==1:
                            h=heuristic(vertex2)
                        else:
                            h=heuristic2(vertex2)
                        total=h+currentcost
                        if vertex2 not in visited or visited[vertex2]>total:
                            visited[vertex2]=total
                            pq.put((total,currentcost,vertex2,path+[vertex2]))
                    if i>2:
                        vertex2=list(vertex[:])
                        vertex2[i],vertex2[i-3]=vertex2[i-3],vertex2[i]
                        vertex2=tuple(vertex2)
                        if x==1:
                            h=heuristic(vertex2)
                        else:
                            h=heuristic2(vertex2)
                        total=h+currentcost
                        if vertex2 not in visited or visited[vertex2]>total:
                            visited[vertex2]=total
                            pq.put((total,currentcost,vertex2,path+[vertex2]))
                    if i<6:
                        vertex2=list(vertex[:])
                        vertex2[i],vertex2[i+3]=vertex2[i+3],vertex2[i]
                        vertex2=tuple(vertex2)
                        if x==1:
                            h=heuristic(vertex2)
                        else:
                            h=heuristic2(vertex2)
                        total=h+currentcost
                        if vertex2 not in visited or visited[vertex2]>total:
                            visited[vertex2]=total
                            pq.put((total,currentcost,vertex2,path+[vertex2]))
    return "no solution"
        
     

class Button(QPushButton):
    double_clicked = QtCore.Signal()

    def __init__(self, *args, **kwargs):
        super(Button, self).__init__(*args, **kwargs)

        self.timer = QtCore.QTimer()
        self.timer.setSingleShot(True)
        self.timer.setInterval(250)
        self.timer.timeout.connect(self.timeout)

        self.isdouble = False

        self.installEventFilter(self)



    def eventFilter(self, obj, event):
        if event.type() == QtCore.QEvent.MouseButtonPress:
            if not self.timer.isActive():
                self.timer.start()

        elif event.type() == QtCore.QEvent.MouseButtonDblClick:
            self.isdouble = True
            return True

        return False

    def timeout(self):
        if self.isdouble:
            self.double_clicked.emit()

        self.isdouble = False

  

class gui(QMainWindow):
    def __init__(self,n):
        super(gui,self).__init__()
        self.var1=0
        self.var2=0
        self.count1=0
        self.frame=QFrame()
        self.frame.setWindowTitle('puzzle solutions ')
        self.frame.setGeometry(500,300,800,500)
        self.frame.show()
        self.a=QLabel("not solvable",self.frame)
        self.a.setGeometry(350,100,50,50)
        self.b1=Button(self.frame)
        self.tup=None
        self.test1=True
        self.b1.setText("solution")
        self.b1.setGeometry(0,30,150,50)
        self.b1.show()
        self.table=QTableWidget(math.sqrt(n),math.sqrt(n),self.frame)
        self.table.setGeometry(0,100,400,200)
        self.table.show()
        self.b1.clicked.connect(self.b1e)
        self.b1.double_clicked.connect(self.b1e2)
        self.b2=Button(self.frame)
        self.b2.setText("choosing start state and heuristic")
        self.b2.setGeometry(180,30,200,50)
        self.b2.show()
        self.b2.clicked.connect(self.b2e)
  
    def b2e(self):
            self.var1=int(input("enter a number from 1-5"))
            self.var2=int(input("enter 1 for the first heuristic and 2 for the second"))
            self.tup=astar(tuple(problems[self.var1-1]),(1,2,3,4,5,6,7,8,0),self.var2)

    def b1e(self):
        if isinstance(self.tup,str):
                self.test1=False
        else:
                self.test1=True
        if self.test1 and self.count1<len(self.tup[2]):
            if self.count1!=len(self.tup[2]):
                l=self.tup[2][self.count1]
                for i in range(int(math.sqrt(9))):
                    for j in range(int(math.sqrt(9))):
                        self.table.setItem(i,j,QTableWidgetItem(str(l[(i*3)+j])))
                self.count1+=1
        if not self.test1:
            self.a.show()

    def b1e2(self):
        self.a.hide()            
    
                    

if __name__ == "__main__":
    app = QApplication(sys.argv)
    run=gui(9)
    sys.exit(app.exec())

