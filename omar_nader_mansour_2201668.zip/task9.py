information_base=[["dry cough","productive cough","runny nose","sneezing","sore throat","watery eyes"],
                  ["Body and muscle aches","chills","dry cough","fatigue","headache","high fever","lack of appetite","vommiting","diarrhea"],
                  ["Body and muscle aches","dry cough","productive cough","diarrhea","vomiting","fatigue","fever","chills","headache",
                   "loss of taste","loss of smell","runny nose","sore throat"]]
def read_symptoms():
    symptoms=list()
    sms=input("enter symptom (enter end to finish)\n")
    while sms !="end":
        symptoms.append(sms)
        sms=input("enter symptom (enter end to finish)\n")
    return symptoms

def inference_engine(symptoms):
    sum=[0,0,0]
    for s in symptoms:
        if s =="loss of smell" or s=="loss of taste":
            return "probably covid"
        elif s=="high fever" or s=="lack of appetite":
            return "probably the flu"
        elif s=="sneezing" or s=="watery eyes":
            return "probably the cold"
        for i in range(3):
            if s in information_base[i]:
                sum[i]+=1
    for i in range(3):
        sum[i]=sum[i]/len(information_base[i])
    index=0
    i=0
    max=sum[0]
    while i<3:
        if sum[i]>max:
            index=i
            max=sum[i]
        i+=1
    if index==0:
        return "probably the cold"
    elif index==1:
        return "probably the flu"
    else:
        return "probably covid"
    
print(inference_engine(read_symptoms()))