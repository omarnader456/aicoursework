points=[(i,j) for i in range(8) for j in range(8)]
actions=["up","down","left","right"]
gamma=0.9
bad_points=[(2,2),(3,3),(4,4),(5,5),(6,6)]
points =[point for point in points if point not in bad_points]

def reward(point,goal):
    if point==goal and goal:
        return 10
    else:
        return -1

def transition(point,action):
    x,y=point
    point2=point
    if action=="up" and x>0:
        point2= x-1,y
    if action =="down" and x<7:
        point2=x+1,y
    if action =="left"and y>0:
        point2= x,y-1
    if action =="right" and y<7:
        point2= x,y+1
    if point2 not in bad_points:
        return point2
    return point

def value_iteration(points,actions,goal,gamma=0.9,theta=1e-4):
    P={p:0 for p in points}
    while True:
        delta =0
        for point in points:
            p=P[point]
            P[point]=max(reward(point,goal)+gamma*P[transition(point,action)] for action in actions)
            delta=max(delta,abs(p-P[point]))
        if delta <theta:
            break
    return P


        
x=int(input("enter row"))
y=int(input("enter column"))
if (x,y) in bad_points:
    while (x,y) in bad_points:
        print("the coordinates are blocked enter a different row and column")
        x=int(input("enter row"))
        y=int(input("enter column"))

goal=(x,y)
values = value_iteration(points,actions,goal)  



print("Optimal State Values in Warehouse:")
for i in range(8):  
    row_values = [f"{values[(i,j)]:6.2f}" if (i,j) not in bad_points else " bad  " for j in range(8) ]
    print(" | ".join(row_values)) 


